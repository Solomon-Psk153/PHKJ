import streamlit as st
import club_make
import club_register

def run():
    club_register.run()
    club_make.run()